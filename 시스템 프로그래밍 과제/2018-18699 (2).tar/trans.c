/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
	int i, j, k, l;
	int tmp0 =0, tmp1=0, tmp2=0, tmp3=0, tmp4=0, tmp5=0;
	if(M==32 && N==32){
	//block 8x8
		for(i=0;i<4;i++){
			for(j=0;j<4;j++){
				for(k=i*8;k<(i+1)*8;k++){
					for(l=j*8;l<(j+1)*8;l++){
						if(k!=l){
							B[l][k] = A[k][l];
						}else{
						// avoid cache miss
							tmp0 = A[k][k];
							tmp1=l;
						}
					}
					if(i==j){
						B[tmp1][tmp1] = tmp0;
					}
				}
			}
		}
		
	}
	else if(M==64 && N == 64){
		for(i=0;i<8;i++){
			for(j=0;j<8;j++){
			//divide 8x8 matrix
					//block1
					for(l=0;l<4;l++){
						tmp0 = A[i*8+l][j*8];
						tmp1 = A[i*8+l][j*8+1];
						tmp2 = A[i*8+l][j*8+2];
						tmp3 = A[i*8+l][j*8+3];
						B[j*8][i*8+l] = tmp0;
						B[j*8+1][i*8+l] = tmp1;
						B[j*8+2][i*8+l] = tmp2;
						B[j*8+3][i*8+l] = tmp3;
					}
					//block3
					for(l=0;l<4;l++){
						tmp0 = A[i*8+l+4][j*8];
						tmp1 = A[i*8+l+4][j*8+1];
						tmp2 = A[i*8+l+4][j*8+2];
						tmp3 = A[i*8+l+4][j*8+3];
						B[j*8][i*8+l+4] = tmp0;
						B[j*8+1][i*8+l+4] = tmp1;
						B[j*8+2][i*8+l+4] = tmp2;
						B[j*8+3][i*8+l+4] = tmp3;
						
					}
					
					//block4
					for(l=0;l<4;l++){
						tmp0 = A[i*8+l+4][j*8+4];
						tmp1 = A[i*8+l+4][j*8+5];
						tmp2 = A[i*8+l+4][j*8+6];
						tmp3 = A[i*8+l+4][j*8+7];
						B[j*8+4][i*8+l+4] = tmp0;
						B[j*8+5][i*8+l+4] = tmp1;
						
						B[j*8+6][i*8+l+4] = tmp2;
						B[j*8+7][i*8+l+4] = tmp3;
					}
					//block2
					for(l=0;l<4;l++){
						tmp0 = A[i*8+l][j*8+4];
						tmp1 = A[i*8+l][j*8+5];
						tmp2 = A[i*8+l][j*8+6];
						tmp3 = A[i*8+l][j*8+7];
						B[j*8+4][i*8+l] = tmp0;
						B[j*8+5][i*8+l] = tmp1;
						
						B[j*8+6][i*8+l] = tmp2;
						B[j*8+7][i*8+l] = tmp3;
						}
	
		}
		}
	
}
	else if(M==61 && N == 67){
	//transpose 64x61
		for(i=0;i<8;i++){
			for(j=0;j<8;j++){
				for(k=i*8;k<(i+1)*8;k++){
					for(l=j*8;l<(j+1)*8 && l<61;l++){
				
					if(k!=l){
					
						B[l][k]=  A[k][l];
					}
					else{
						tmp4 = A[k][k];
						tmp5 = l;
					}

					}
					if(i==j){
					B[tmp5][tmp5] = tmp4;
					}
				
				}
			}
		
		}
		
		//A[64][] ~ A[66][]
			for(l=0;l<61;l++){
			tmp0 = A[64][l];
			B[l][64] = tmp0;
			tmp1 = A[65][l];
			B[l][65] =tmp1;
			tmp2 = A[66][l];
			B[l][66] = tmp2;
			}
	
	}
	
}
/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

