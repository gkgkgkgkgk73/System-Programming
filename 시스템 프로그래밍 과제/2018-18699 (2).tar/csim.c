#include "cachelab.h"
#include <unistd.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

typedef struct {
	int tag;
	int valid;
	int lru;
} cache_line_t;

typedef cache_line_t* cache_set_t;
typedef cache_set_t* cache_t;
void process(char identifier, int address, int size);

int hits =0;
int misses=0;
int evicts=0;
int lru_counter=1;
unsigned int set_index_mask;
char *t = NULL;

cache_t cache;
int s,E,b,S;
 
int main(int argc, char* argv[])
{
    int opt=0;
   
    //get arguments
    while(-1!=(opt = getopt(argc, argv, "s:E:b:t:"))){
    switch(opt){
    	case 's':
    		s = atoi(optarg);
    		break;
    	case 'E':
    		E = atoi(optarg);
    		break;
    	case 'b':
    		b = atoi(optarg);
    		break;
    	case 't':
    		t = optarg;
    		break;
    	default:
    		printf("wrong argument\n");
    		break;
    		
    }}

    //init cache
    S = pow(2,s);
    
    cache = (cache_set_t*)malloc(sizeof(cache_set_t)*S);
    for(int i=0;i<S;i++){
    	cache[i] = (cache_line_t*)malloc(sizeof(cache_line_t)*E);
    	for(int j=0;j<E;j++){
    		cache[i][j].valid = 0;
    	}
    }
    

    //open trace file
    FILE * pFile;
    
    pFile = fopen(t, "r");
    if(pFile == NULL){
    	printf("file open error");
    	return(-1);
    }
 
    char identifier;
    unsigned int address;
    int size;
    
    while(fscanf(pFile," %c %x,%d", &identifier, &address, &size)>0)
    {
    	
    	//process each instruction
    	switch(identifier){
    		case 'L':{
    			process(identifier, address, size);
    			break;}
    		case 'S':
    			{
    			process(identifier, address, size);
    			break;}
    		case 'M':
    			{
    			process(identifier, address, size);
    			process(identifier, address, size);
    			break;}
    		default:
    			break;
    	
    	}
    	
    }
    fclose(pFile);
    free(cache);
    printSummary(hits, misses, evicts);
    return 0;
}

void process(char identifier, int address, int size){

	unsigned int lru_max = UINT_MAX;
    	int evict_line = 0;
    	
	int tag = ((address>>(s+b))&0xffffffff);
    	int set_index = ((address>>b)&(0x7fffffff >> (31-s)));
    	for(int i=0;i<E;i++){
    		if(cache[set_index][i].valid){
    			if(cache[set_index][i].tag == tag){
    				cache[set_index][i].lru = lru_counter++;
    				hits++;
    				return;
    			}		
    		}
    	}
    	misses++;
    			
    	for(int i=0;i<E;i++){
    		if(lru_max >cache[set_index][i].lru){
    			evict_line = i;
    			lru_max = cache[set_index][i].lru;
    		}
    	}
    			
    	if(cache[set_index][evict_line].valid){
    		evicts++;
    	}
    			
    	cache[set_index][evict_line].valid = 1;
    	cache[set_index][evict_line].tag = tag;
    	cache[set_index][evict_line].lru = lru_counter++;
}










